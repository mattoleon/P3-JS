
    const diaporama = new Diaporama(4000,false); // Appel de l'objet Diaporama
    const map = new Map(); // Appel de l'objet Map (dans lequel on appel les objets Canvas, Booking et Confirmed)
    const canvas = new Canvas(map);
    const confirmed = new Confirmed(false, 1, 20, 4000);


