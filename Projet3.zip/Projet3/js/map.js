   // Initialisation de la map Leaflet + ajouts des marqueurs bleus et rouges.
class Map {
    constructor() {
        this.markers =[];
        this.APIUrl = "https://api.jcdecaux.com/vls/v1/stations?contract=marseille&apiKey=7c43f9e473d0eaa56c1bb29111da803fa5d4ed88";
        this.markerClusters = new L.MarkerClusterGroup();
        this.booking;
        this.stations;
        this.iconBlue = L.icon({
            iconUrl: 'img/markerblue.svg',
            iconSize: [48, 48], 
            iconAnchor: [22, 50],
            className : 'markerActive'
        })
        this.iconRed = L.icon({
            iconUrl: 'img/markerred.svg',
            iconSize: [48, 48], 
            iconAnchor: [22, 50],
            className : 'markerActive'
        })
        this.mapTile();
        this.ajaxRequest();
    }   

    // Coordonnées de la map + tuiles personnalisées pour l'affichage de la carte (L.tileLayer).
    mapTile =()=> {
        this.mapTile = L.map('carte').setView([43.29, 5.39], 14),
        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        // Il est toujours bien de laisser le lien vers la source des données
        attribution: 'données © <a href="//osm.org/copyright">OpenStreetMap</a>/ODbL - rendu <a href="//openstreetmap.fr">OSM France</a>',
        minZoom: 12,
        maxZoom: 17
        }).addTo(this.mapTile);
    }
    
    // AJOUT DES MARQUEURS SUR LA CARTE
    marqueurs = (response) =>{
        // Appel de la requête
        this.stations = JSON.parse(response);
        
        // On parcours le tableau JSON pour rechercher chaque station    
        for (let station in this.stations){
            let s = this.stations[station]; // Ici, mini variable pour simplifier la lecture
            let icon;
            let isOpen;
            // Si la station est ouverte et que vélos > 0, icone bleu
            if (s.status === "OPEN" && s.available_bikes !== 0){
                icon = this.iconBlue;
                isOpen = true;
            } else { // Sinon, icone rouge.
                icon = this.iconRed;
                isOpen = false;
            }   
            let marker = L.marker([s.position.lat,s.position.lng]).setIcon(icon);
            this.markers.push(marker);
            this.markerClusters.addLayer(marker); 

            // Au clic sur le marqueur, affiche les infos venant de "booking.js"
            marker.addEventListener('click', () => {
                formulaire.scrollIntoView({ behavior: 'smooth' , block: 'start', inline: 'end'});
                this.booking = new Booking(isOpen, s.address, s.available_bikes, s.available_bike_stands, canvas);
            })
        }                
        // AJOUT DES CLUSTERS
        this.mapTile.addLayer(this.markerClusters);
    } 
    
    // APPEL DE L'OBJET AJAX
    ajaxRequest = () => {
        let ajaxGetRequest = new AjaxGetRequest(this.APIUrl, this.marqueurs);
    }
}

