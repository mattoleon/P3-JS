// OBJET CANVAS
class Canvas {
     constructor() {
        this.canvas = document.getElementById("canvas"); // Initialisation de la zone canvas
        this.erase = document.getElementById("delete"); // Efface la signature
        this.valid = document.getElementById("valid"); // Valide la signature et affiche la réservation
        this.cancelbookingyes = document.getElementById("cancelbookingyes"); // Créer une nouvelle réservation et annule l'ancienne
        this.cancelbookingno = document.getElementById("cancelbookingno"); // Annule nouvelle réservation
        this.context = this.canvas.getContext("2d"); // Initialise l'API CANVAS
        this.context.strokeStyle = "#393939"; // Couleur du trait
        this.context.lineWidth = "1"; // Epaisseur de la ligne
        this.context.lineCap = "round"; // Style de l'extrémité de la ligne
        this.context.lineJoin = "round"; // Style de jointure entre deux lignes
        this.writting = false; // L'utilisateur est en train d'écrire sur la zone CANVAS
        this.checkCanvas = false; // L'utilisateur a écrit sur le canvas
        //this.signing(); // Méthode signature sur le CANVAS
     }

     signing=()=> {
        // LORSQU'ON PRESSE LA SOURIS
        this.canvas.addEventListener("mousedown", (e) => {
          e.preventDefault();
          this.context.beginPath(); // commencer à tracer la ligne
          this.writting = true; // l'utilisateur est en train d'écrire
          this.checkCanvas = true;
        });

        // LORSQU'ON BOUGE LA SOURIS
        this.canvas.addEventListener("mousemove", (e) => {
          e.preventDefault();
          // Si l'utilisateur écrit
          if (this.writting) {
            this.context.lineTo(e.offsetX, e.offsetY); // trace une ligne sur l'axe X et Y du pointeur de la souris entre cet évènement et la bordure de la marge intérieure du noeud cible.
            this.context.stroke();
          }
        });

       // LORSQU'ON RELÈVE LA SOURIS
        this.canvas.addEventListener("mouseup", (e) => {
          e.preventDefault();

          // Si l'utilisateur est en train d'écrire
          if (this.writting) {
            this.writting = false; // Cesse d'écrire
          }
        });

      // LORS D'UN TOUCH SUR LE CANVAS
      this.canvas.addEventListener("touchstart", (e) => {
          e.preventDefault();
          this.checkCanvas = true;
          this.context.beginPath(); // commencer à tracer la ligne
          this.writting = true; // l'utilisateur est en train d'écrire
        });

        // LORSQU'ON DÉPLACE SON DOIGT SUR LE CANVAS
        this.canvas.addEventListener("touchmove", (e) => {
          e.preventDefault();

          let canvasCss = event.target.getBoundingClientRect(); // variable pour définir un rectangle à partir de la zone ciblée par l'évènement
          let movePosition = e.changedTouches[0]; // variable pour enregistrer les différents points d'entrée où l'utilisateur pose le doigt
          // Si l'utilisateur écrit
          if (this.writting) {
            this.context.lineTo(movePosition.clientX - canvasCss.left, movePosition.clientY - canvasCss.top);
            //trace une ligne entre la position sur l'axe X et Y par rapport à la zone ciblée par l'évenement
            this.context.stroke();
          }
        });

        // LORSQU'ON RELÈVE LE DOIGT
        this.canvas.addEventListener("touchend", (e) => {
          e.preventDefault();
          /*si l'utilisateur écrit*/
          if (this.writting) {
            this.writting = false; // cesser d'écrire
          }
        });

        // LORSQU'ON CLIQUE SUR LE BOUTON "EFFACER"
        this.erase.addEventListener('click', (e) => {
             e.preventDefault();
          this.checkCanvas = false; // il n'y a pas de signature sur le canvas
          this.context.clearRect( 0, 0, this.context.canvas.width, this.context.canvas.height); // effacer la zone CANVAS dans sa totalité en largeur et hauteur
        });


        // LORSQU'ON CLIQUE SUR LE BOUTON "VALIDER"
        this.valid.addEventListener('click',(e) => {
            e.preventDefault();
            
            if (this.checkCanvas == true && confirmed.booked == false) {
                document.getElementById("zonecanvas").style.display = "none";
                document.getElementById("resa").style.display = "flex";
                this.context.clearRect( 0, 0, this.context.canvas.width, this.context.canvas.height);
                resa.scrollIntoView({ behavior: 'smooth' , block: 'start', inline: 'nearest'});
                confirmed.showBooking(confirmed.timeS,confirmed.timeM);
                this.checkCanvas = false;
                 
            } else if(this.checkCanvas == true && confirmed.booked == true) {
                document.getElementById("newbooking").style.display ="block";
                document.getElementById("zonecanvas").style.display = "none";
            }
            if(sessionStorage.setItem('seconds') !== null && sessionStorage.setItem('minutes') !==null) {
                confirmed.clearStorage();
                confirmed.reset();  
            } 
        })

        // LORSQU'ON SOUHAITE FAIRE UNE NOUVELLE RESERVATION
        this.cancelbookingno.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById("newbooking").style.display ="none";
        })
        this.cancelbookingyes.addEventListener('click', (e) => {
            e.preventDefault();
            confirmed.reset();
            document.getElementById("newbooking").style.display = "none";
            //document.getElementById("resa").style.display = "flex";
            this.context.clearRect( 0, 0, this.context.canvas.width, this.context.canvas.height);
            resa.scrollIntoView({ behavior: 'smooth' , block: 'start', inline: 'nearest'});
            confirmed.showBooking(confirmed.timeS,confirmed.timeM);
            this.checkCanvas = false;
            

        })
    }
}
