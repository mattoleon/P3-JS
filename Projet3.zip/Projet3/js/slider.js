class Diaporama {
    constructor (time,inProgress) {
        this.images = document.getElementsByClassName("images");
        this.nextButton = document.getElementById("next");
        this.previousButton = document.getElementById("previous"); 
        this.pauseButton = document.getElementById("timeButton");
        this.read = 0;
        this.time = time; // Temps à définir entre 2 intervalles 
        this.inProgress = inProgress; // Le temps est en train de s'écouler entre 2 diapos
        this.timeOut;
        this.init();   
        this.events();
        this.autoplay();

    }

    // INITIALISATION DU TABLEAU DES IMAGES
    init = () =>{
        this.images[0].style.zIndex="2";
        this.images[1].style.zIndex="1";
        this.images[2].style.zIndex="0";
    }

    // LANCE LA FONCTION AUTOPLAY
    autoplay = () =>{

        if(this.inProgress == true){
           
             this.timeOut = setTimeout(() => {

                this.next();
                this.autoplay();

            },this.time);   
        } 
        
    }
   
     // FONCTION "NEXT"
   
    next = () =>{  

        if(this.read == this.images.length-1){
            this.read=0;
            this.images[this.read].style.zIndex="2";
            this.images[this.images.length-1].style.zIndex="0";
        } else {
            this.images[this.read].style.zIndex="1";
            this.images[this.read+1].style.zIndex="2";
            this.read++;
        }
        
    }

    // FONCTION "PREVIOUS"
    previous = () =>{

    if(this.read == 0){
            this.read=this.images.length-1;
            this.images[this.read].style.zIndex="2";
            this.images[0].style.zIndex="0";
        } else {
            this.images[this.read].style.zIndex="1";
            this.images[this.read-1].style.zIndex="2";
            this.read--;
        }

    }

    // FONCTION "PAUSE"
    pause = () =>{
        
        if(this.inProgress == true){
            clearTimeout(this.timeOut);  
            this.inProgress = false;
            timeButton.innerHTML = 'Comment ça marche ?';

        }else{
            this.inProgress = true;
            this.autoplay();
            timeButton.innerHTML = 'Pause';
        };
        
    }


    // EVENEMENTS GRÂCE AUX ÉCOUTEURS SUR LES CLICS
    events = () =>{ 
        this.nextButton.addEventListener('click',()=>{
            this.next(); // Sur Next
        });

        this.previousButton.addEventListener('click', ()=>{
            this.previous(); // Sur Previous
        });

        window.addEventListener('keydown', e => {
            if (e.key === 'ArrowRight') {
                this.next() // Avec les touches du clavier
            }  else if (e.key === 'ArrowLeft' ) {                
                this.previous()
            }
        })
        
        this.pauseButton.addEventListener('click', ()=> {
            this.pause(); // Sur bouton Pause
        }); 
    }
}
