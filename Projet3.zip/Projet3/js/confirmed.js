class Confirmed {
    constructor (booked, timeS, timeM, timeOut) {
        this.booked = booked;
        this.timeS = timeS;
        this.timeM = timeM;
        this.timeOut = timeOut;
    }

    // AFFICHE LE TIMER AVEC DEUX CHIFFRES ("09 secondes" au lieu de "9 secondes")
    timeToString = (time) => {
        let formatted = "00";
        if (time && isNaN(time) === false) {
            formatted = time.toString();
            if (time < 10) {
                formatted = "0" + formatted;
            }
        }
        return formatted;
    }
    
    // AFFICHE LA RESERVATION ET LANCE TIMER, INFOPLACE ET CONFIRMCANCEL
    showBooking = (s,m) => {
        this.timer(s,m);   
        this.confirmCancel();
        this.infoBooking();
        this.booked = true;
    }

    // TIMER DE LA RESERVATION
    timer = (s, m) => {
        
        let timeText = document.getElementById("timercount");

           this.interval = setInterval(() => {
            if (s == 0){ s = 60; m -= 1}
            s -= 1;
            timeText.innerHTML = this.timeToString(m) + ':' + this.timeToString(s);
            // Change la couleur du timer lorsqu'il passe en dessous de 1 minute
            if ( s < 60 && m === 0) {
                timeText.style.color = "red";
            } else {
                timeText.style.color = "#029ddc";
            }
            sessionStorage.setItem("seconds",s);  
            sessionStorage.setItem("minutes",m); 
            // Lorsque le timer arrive à 00:00
            if(s === 0 && m === 0) {
                document.getElementById("resa").style.display = "none";
                document.getElementById("infos-resa").style.display = "block";
                document.getElementById("askcancel").style.display = "none";
                this.reset();
                this.alertDialog();
            }    
        }, 1000)
    }

    // AFFICHE L'ADRESSE DE LA RESERVATION DANS L'ESPACE "RESERVATION"
    infoBooking = () => {
        document.getElementById("resa-name").innerText = map.booking.prenom;
        document.getElementById("place-info").innerHTML = "Adresse de la station :<br>" + map.booking.address;
    }
    
    // DEMANDE SI ON ANNULER LA RESERVATION EN COURS
    confirmCancel = () => { // Au clic sur annuler, affiche la zone "askcancel"
            document.getElementById('annuler').addEventListener('click',() => {
            document.getElementById("infos-resa").style.display = "none";
            document.getElementById("askcancel").style.display = "block";
        });
         
            // Si clilc sur "cancelno", on revient à l'écran précédent
            document.getElementById('cancelno').addEventListener('click', () => {
            document.getElementById("infos-resa").style.display = "block";
            document.getElementById("askcancel").style.display = "none";
            
        }); // Si clic sur "cancelyes", on annule la réservation et on masque la zone
            document.getElementById('cancelyes').addEventListener('click', () => {
            document.getElementById("resa").style.display = "none";
            document.getElementById("infos-resa").style.display = "block";
            document.getElementById("askcancel").style.display = "none";
            this.reset();
            this.alertDialog();
        });   
    }

    // FONCTION POUR ARRETER LE TIMER
    reset = () => {
        clearInterval(this.interval);
        document.getElementById("timercount").innerHTML ='';
        this.booked = false;
    }

    clearStorage() {
        sessionStorage.removeItem("seconds");
        sessionStorage.removeItem("minutes");
    }

    // ALERT LORSQUE LA RESERVATION EST ANNULE (ARRIVE À 00:00)
    alertDialog = () => {
        document.getElementById('alertinfo').style.display = "block";  
        document.getElementById('closebtn').addEventListener('click', () => {
            document.getElementById('alertinfo').style.display = "none";
        });
        setTimeout(()=> {
            document.getElementById('alertinfo').style.display = "none";
            alertinfo.scrollIntoView({ behavior: 'smooth' , block: 'start', inline: 'nearest'});
        },this.timeOut);
    } 
}

