class Booking {
    constructor (open, address, bikes, stands, canvas) {
        this.open = open; // La station est ouverte
        this.address = address;
        this.bikes = bikes; // Nombre de vélos disponibles
        this.stands = stands; // Nombre de places restantes
        this.canvas = canvas;
        this.showInfos();
        this.showCanvas();
        this.isOpen();
        this.activeSign();

    }

    // AFFICHE LES INFOS LORSQU'ON A CLIQUÉ SUR UN MARQUEUR
    showInfos = () => {
        document.getElementById("place").innerHTML = "<span>Adresse de la station :</span><br>"  + this.address.toUpperCase();
        document.getElementById("bikes").innerHTML = "Vélos disponibles : "  + this.bikes;
        document.getElementById("stands").innerHTML = "Places disponibles : "  + this.stands;
        sessionStorage.setItem("address", this.address);
        
    }

    // LOCAL STORAGE POUR NOM ET PRENOM

    fillFields = () => {
        this.prenom = document.getElementById("prenom").value;
        this.nom = document.getElementById("nom").value;
        localStorage.setItem("prenom", prenom);
        localStorage.setItem("nom", nom);
    }

    // CHANGE L'ÉTAT DU BOUTON "SIGNATURE" LORSQUE "NOM" ET "PRENOM" SONT REMPLIS
    activeSign = () => {
        let input = document.getElementById('formulaire');
        input.addEventListener("input", () => {
            this.fillFields();
            if(this.prenom !== "" && this.nom !== "") {
                document.getElementById("sign").style.opacity = "1";
            } else {
                document.getElementById("sign").style.opacity = "0.3";
            }
        }); 
    }
  
    // AFFICHE LE CANVAS APRÈS CLIC SUR SIGNATURE     
    showCanvas = () => {
        document.getElementById("sign").addEventListener("click", () => {
            this.fillFields();
            if(this.prenom !== "" && this.nom !== "") {
                document.getElementById("zonecanvas").style.display = "block";
                document.getElementById("canvas").style.display = "block";
                this.canvas.signing(); // Appel de l'objet Canvas
            }
        })
         // Annule l'affichage du canvas en changeant le display > to "none" après clic sur "annuler"
            document.getElementById("cancel").addEventListener("click", () => {
            document.getElementById("zonecanvas").style.display = "none";
        })
    }

    // VÉRIFIE SI LA STATION EST OUVERTE
    isOpen = () => {
        if(this.open) {
            document.getElementById("alert").innerHTML = '<div class="alert-success" role="alert"> Réservation possible ! </div>';
            document.getElementById("formulaire").style.display = "block";  
        } else {
            document.getElementById("alert").innerHTML = '<div class="alert-danger" role="alert">Réservation non disponible actuellement. </div>';
            document.getElementById("formulaire").style.display = "none";
        }
    }
}


